import 'package:flutter/material.dart';
import 'package:libraryappbyshahid/components/appbar_component.dart';
import 'package:libraryappbyshahid/components/book_issuecard_component.dart';

class StudentViewBooks extends StatefulWidget {
  const StudentViewBooks({Key? key}) : super(key: key);

  @override
  State<StudentViewBooks> createState() => _StudentViewBooksState();
}

class _StudentViewBooksState extends State<StudentViewBooks> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarComponent("View Books"),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            BookIssueCardComponent()
          ],
        ),
      ),
    );
  }
}
