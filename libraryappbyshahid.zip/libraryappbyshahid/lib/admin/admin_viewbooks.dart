import 'package:flutter/material.dart';
import 'package:libraryappbyshahid/components/appbar_component.dart';
import 'package:libraryappbyshahid/components/bookcard_component.dart';
class AdminViewbooks extends StatefulWidget {
  const AdminViewbooks({Key? key}) : super(key: key);

  @override
  State<AdminViewbooks> createState() => _AdminViewbooksState();
}

class _AdminViewbooksState extends State<AdminViewbooks> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarComponent("View Books"),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: ListView(
          children: [
            BookCard(),
            BookCard(),
          ],
        ),
      ),
    );
  }
}
