import 'package:flutter/material.dart';
import 'menuitem_component.dart';
class DrawerComponent extends StatelessWidget {
  const DrawerComponent({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: [
          UserAccountsDrawerHeader(
            accountName: Text("Admin"),
            accountEmail: null,
            currentAccountPicture: CircleAvatar(
              child: Icon(Icons.person,color: Colors.white,),
              backgroundColor: Color(0xff4e058f),
            ),
          ),
          MenuitemComponent(Icons.home,"Dashboard", Colors.deepPurple),
          MenuitemComponent(Icons.add_card_rounded,"Add Book", Colors.pink)

        ],
      ),
    );
  }
}
