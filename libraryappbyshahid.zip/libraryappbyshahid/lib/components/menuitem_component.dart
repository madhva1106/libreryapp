import 'package:flutter/material.dart';
class MenuitemComponent extends StatelessWidget {
  IconData icondata;
  String text;
  Color color;

  MenuitemComponent(this.icondata,this.text,this.color);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icondata,color: color,size: 30,),
      title: Text(text,style: TextStyle(fontSize: 20),),
    );
  }
}
